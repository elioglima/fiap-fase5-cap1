﻿using System.Text.Json.Serialization;

namespace Greenlight.Entitys
{
    public class TipoPessoa
    {
        public int PJ { get; } = 1;
        public int PF { get; } = 2;

    }
}
