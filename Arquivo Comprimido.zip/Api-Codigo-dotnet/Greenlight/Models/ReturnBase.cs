﻿namespace Greenlight.Models
{
    interface ReturnBase
    {
        public bool? error { get; set; }

        public string? mensagem { get; set; }
    }
}
