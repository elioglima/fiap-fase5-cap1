﻿using System.Text.Json.Serialization;
using Greenlight.Entitys;

namespace Greenlight.Models
{
    public class EventoServiceRequisicao: Evento
    {


    }
}
